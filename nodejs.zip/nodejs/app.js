const express = require('express');
const bodyParser = require('body-parser');
const path = require('path');
const app = express();

const db = require('./config/db');
const productosRoutes = require('./routes/productos');

app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());
app.use(express.static(path.join(__dirname, 'public')));
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

app.get('/', (req, res) => {
    const query = 'SELECT * FROM productos';
    db.query(query, (err, results) => {
        if (err) {
            console.error('Error al obtener productos:', err);
            res.status(500).send('Error en el servidor');
        } else {
            const stockBajo = results.filter(p => p.stock < 10).length;
            const valorTotal = results.reduce((a, p) => a + (parseFloat(p.precio) * parseInt(p.stock)), 0).toFixed(2);

            res.render('index', {
                productos: results,
                stockBajo: stockBajo,
                valorTotal: valorTotal
            });
        }
    });
});

app.use('/api', productosRoutes);

const port = 3000;
app.listen(port, () => {
    console.log(`Servidor ejecutándose en http://localhost:${port}`);
});