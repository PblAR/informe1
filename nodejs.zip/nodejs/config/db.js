const mysql = require('mysql');

// Configuración de la conexión a MySQL
const connection = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: '', // Por defecto en XAMPP está vacío
  database: 'inventario_tienda' // Asegúrate de que coincida con phpMyAdmin
});

// Verificación de la conexión
connection.connect((err) => {
  if (err) {
    console.error('Error conectando a la base de datos: ' + err.stack);
    return;
  }
  console.log('Conexión establecida con éxito a MySQL.');
});

module.exports = connection;