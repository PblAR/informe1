const connection = require('../config/db');
exports.listarProductos = (req, res) => {
    connection.query("SELECT * FROM productos", (err, results) => {
        if (err) return res.status(500).json({ error: 'Error al consultar' });
        res.json(results);
    });
};
exports.crearProducto = (req, res) => {
    let imagenPath = req.body.imagen || '';
    if (req.file) imagenPath = '/uploads/' + req.file.filename;

    const producto = {
        nombre: req.body.nombre,
        precio: req.body.precio,
        stock: req.body.stock,
        imagen: imagenPath
    };
    connection.query('INSERT INTO productos SET ?', producto, (err) => {
        if (err) { console.error(err); return res.status(500).send("Error al crear"); }
        res.redirect('/');
    });
};
exports.obtenerProductoPorId = (req, res) => {
    connection.query("SELECT * FROM productos WHERE id = ?", [req.params.id], (err, result) => {
        if (err) throw err;
        res.json(result[0]);
    });
};
exports.actualizarProducto = (req, res) => {
    let imagenPath = req.body.imagen || '';
    if (req.file) imagenPath = '/uploads/' + req.file.filename;

    const datos = {
        nombre: req.body.nombre,
        precio: req.body.precio,
        stock: req.body.stock,
        imagen: imagenPath
    };
    connection.query("UPDATE productos SET ? WHERE id = ?", [datos, req.params.id], (err) => {
        if (err) throw err;
        res.redirect('/');
    });
};
exports.eliminarProducto = (req, res) => {
    connection.query("DELETE FROM productos WHERE id = ?", [req.params.id], (err) => {
        if (err) { console.error(err); return res.status(500).send("Error al eliminar"); }
        res.redirect('/');
    });
};