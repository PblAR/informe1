const express = require('express');
const router = express.Router();
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const productosController = require('../controllers/productosController');

// Configurar multer aquí directamente
const uploadsDir = path.join(__dirname, '../uploads');
if (!fs.existsSync(uploadsDir)) fs.mkdirSync(uploadsDir);

const storage = multer.diskStorage({
    destination: (req, file, cb) => cb(null, uploadsDir),
    filename: (req, file, cb) => {
        const unique = Date.now() + '-' + Math.round(Math.random() * 1e9);
        cb(null, unique + path.extname(file.originalname));
    }
});
const upload = multer({ storage });

router.get('/productos', productosController.listarProductos);
router.post('/productos', upload.single('imagen_archivo'), productosController.crearProducto);
router.get('/productos/:id', productosController.obtenerProductoPorId);
router.put('/productos/:id', upload.single('imagen_archivo'), productosController.actualizarProducto);
router.get('/productos/delete/:id', productosController.eliminarProducto);
router.delete('/productos/:id', productosController.eliminarProducto);

module.exports = router;