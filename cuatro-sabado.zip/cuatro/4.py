import cv2
import numpy as np

camara = cv2.VideoCapture(0)

while True:
    ret, frame = camara.read()

    if not ret:
        break

    hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)

    rojo_bajo1 = np.array([0, 120, 70])
    rojo_alto1 = np.array([10, 255, 255])
    rojo_bajo2 = np.array([170, 120, 70])
    rojo_alto2 = np.array([180, 255, 255])

    mascara1 = cv2.inRange(hsv, rojo_bajo1, rojo_alto1)
    mascara2 = cv2.inRange(hsv, rojo_bajo2, rojo_alto2)
    mascara = mascara1 + mascara2

    resultado = cv2.bitwise_and(frame, frame, mask=mascara)

    cv2.imshow("Imagen original", frame)
    cv2.imshow("Mascara color rojo", mascara)
    cv2.imshow("Objeto rojo detectado", resultado)

    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

camara.release()
cv2.destroyAllWindows()
