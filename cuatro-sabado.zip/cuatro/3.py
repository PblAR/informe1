import cv2

camara = cv2.VideoCapture(0)

while True:
    ret, frame = camara.read()

    if not ret:
        break

    gris = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    bordes = cv2.Canny(gris, 100, 200)

    cv2.imshow("Imagen original", frame)
    cv2.imshow("Bordes detectados", bordes)

    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

camara.release()
cv2.destroyAllWindows()
