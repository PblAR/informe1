import cv2

camara = cv2.VideoCapture(0)

while True:
    ret, frame = camara.read()

    if not ret:
        break

    gris = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

    cv2.imshow("Imagen original", frame)
    cv2.imshow("Imagen en escala de grises", gris)

    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

camara.release()
cv2.destroyAllWindows()
