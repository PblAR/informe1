import cv2

camara = cv2.VideoCapture(0)

while True:
    ret, frame = camara.read()

    if not ret:
        break

    desenfoque = cv2.GaussianBlur(frame, (15, 15), 0)

    cv2.imshow("Imagen original", frame)
    cv2.imshow("Imagen con desenfoque", desenfoque)

    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

camara.release()
cv2.destroyAllWindows()
