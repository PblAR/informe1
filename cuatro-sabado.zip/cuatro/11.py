import cv2

camara = cv2.VideoCapture(0)

if not camara.isOpened():
    print("Error: No se pudo acceder a la cámara.")
else:
    print("Cámara activada correctamente.")

while True:
    ret, frame = camara.read()

    if not ret:
        print("Error: No se pudo capturar la imagen.")
        break

    cv2.imshow("Camara en tiempo real", frame)

    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

camara.release()
cv2.destroyAllWindows()
