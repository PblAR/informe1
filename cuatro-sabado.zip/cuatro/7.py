import cv2  
import numpy as np  

camara = cv2.VideoCapture(0)  

if not camara.isOpened():
    print("Error: No se pudo acceder a la cámara. Verifica la conexión.")
    exit()


contador_capturas = 1

verde_bajo = np.array([35, 40, 40])   
verde_alto = np.array([90, 255, 255])  

print("===============================================================")

print("¡Sistema de Visión por Computadora Iniciado Correctamente!")
print(" -> Coloca un objeto VERDE frente a la cámara.")
print(" -> Presiona la tecla 'S' para guardar una captura de evidencia.")
print(" -> Presiona la tecla 'Q' para cerrar el programa de forma segura.")
print("===============================================================")

while True:      
    
    ret, frame = camara.read()      
    if not ret:          
        print("Error: No se pudo recibir el cuadro de la cámara.")
        break      
    

    hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)      
    
   
    mascara = cv2.inRange(hsv, verde_bajo, verde_alto)      
    
   
    contornos, _ = cv2.findContours(mascara, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)      
    
   
    for contorno in contornos:          
       
        area = cv2.contourArea(contorno)          
        
    
        if area > 600:              
             
            x, y, w, h = cv2.boundingRect(contorno)              
           
            cv2.rectangle(frame, (x, y), (x + w, y + h), (0, 255, 0), 2)              
            
           
            cv2.putText(frame, "Objeto Verde Detectado", (x, y - 10), 
                        cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 0), 2)      
    
    
    cv2.imshow("Video Original - Deteccion por Contornos", frame)      
    cv2.imshow("Mascara Binaria (Filtro HSV)", mascara)      
    
    
    tecla = cv2.waitKey(1) & 0xFF      
    
    if tecla == ord('s') or tecla == ord('S'):          
        nombre_archivo = f"evidencia_verde_{contador_capturas}.jpg"          
        
        cv2.imwrite(nombre_archivo, frame)          
        print(f"[OK] Captura de pantalla guardada con éxito como: '{nombre_archivo}'")          
        contador_capturas += 1      
        
   
    if tecla == ord('q') or tecla == ord('Q'):          
        print("\nCerrando el software de forma segura...")
        break  

camara.release()  
cv2.destroyAllWindows()
print("Recursos liberados. Programa finalizado correctamente.")