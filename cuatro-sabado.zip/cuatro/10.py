import cv2  
import numpy as np  

camara = cv2.VideoCapture(0)  
contador = 1  

color_bajo = np.array([40, 70, 70])  
color_alto = np.array([80, 255, 255])  

print("Programa iniciado. Presiona 'S' para capturar o 'Q' para salir.")

while True:      
    ret, frame = camara.read()      
    if not ret:          
        print("No se pudo capturar la imagen.")          
        break      
    
    
    hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)      
    mascara = cv2.inRange(hsv, color_bajo, color_alto)      
    
    
    contornos, _ = cv2.findContours(mascara, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)      
    
    for contorno in contornos:          
        area = cv2.contourArea(contorno)          
        if area > 500: # Filtro de ruido              
            x, y, w, h = cv2.boundingRect(contorno)              
            
            
            cv2.rectangle(frame, (x, y), (x+w, y+h), (0, 255, 0), 2)              
            
            
            cv2.putText(frame, "Objeto detectado", (x, y-10), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 0), 2)      
    
   
    cv2.imshow("Reto final", frame)      
    cv2.imshow("Mascara", mascara)      
    
    tecla = cv2.waitKey(1) & 0xFF      
    
    if tecla == ord('s') or tecla == ord('S'):          
        nombre = f"evidencia_{contador}.jpg"          
        cv2.imwrite(nombre, frame)          
        print(f"Imagen guardada con éxito como: {nombre}")          
        contador += 1      
        
    if tecla == ord('q') or tecla == ord('Q'):          
        print("Cerrando el programa...")
        break  

# Liberar los recursos
camara.release()  
cv2.destroyAllWindows()
print("Recursos liberados correctamente.")