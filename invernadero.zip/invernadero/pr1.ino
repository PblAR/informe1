/*
 * ╔══════════════════════════════════════════════════════════════╗
 *  SISTEMA INVERNADERO INTELIGENTE — v3.0   Arduino MEGA 2560
 * ╠══════════════════════════════════════════════════════════════╣
 *  PINES:
 *   LCD I2C         : SDA=20, SCL=21
 *   DHT22           : 22
 *   Teclado filas   : 6,7,8,9  | columnas: 10,11,12
 *   LED Verde       : 4
 *   LED Rojo        : 5
 *   Buzzer          : 13
 *   LED RGB 1       : R=39, G=40, B=41  (indicador riego 1)
 *   LED RGB 2       : R=42, G=43, B=44  (indicador riego 2 / estado)
 *   Barra LED 1     : 23,24,25,26,27,28,29,30  (animación riego 1)
 *   Barra LED 2     : 45,46,47,48,49,50,51,52  (animación riego 2)
 *   Servo ventil.   : 53
 *   HC-SR04         : TRIG=54, ECHO=55
 *   Stepper 1       : 31,32,33,34   (bomba riego principal)
 *   Stepper 2       : 35,36,37,38   (bomba secundaria / drenaje)
 *   Sensores Analog : A0=HumedadSuelo, A1=Lluvia, A2=NivelAgua, A3=Luz
 * ╠══════════════════════════════════════════════════════════════╣
 *  TECLADO — MODO MANUAL:
 *   1 → Ver Temperatura
 *   2 → Ver Humedad Ambiente
 *   3 → Ver Humedad Suelo
 *   4 → Ver Estado del Sistema (agua, riego, vent.)
 *   5 → Submenú RIEGO  →  1=Activar  2=Desactivar
 *   6 → Ventilación ON/OFF
 *   7 → Barra LED ON/OFF
 *   8 → Toggle horario seguridad
 *   9 → Ver litros de agua restantes
 *   0 → Menú manual
 *   # → Volver a selección de modo
 * ╠══════════════════════════════════════════════════════════════╣
 *  LÓGICA CONDICIONAL MÚLTIPLE:
 *   Riego   : suelo seco  AND  no llueve  AND  agua > 0
 *   Venti   : temperatura ≥ 25 °C  (4 niveles escalonados)
 *   AlTemp  : temperatura > 35 °C  OR  temperatura < 12 °C
 *   BarraL  : luz < umbral  AND  modo AUTO
 *   Segur.  : distancia < 100 cm  AND  !horarioPermitido
 * ╠══════════════════════════════════════════════════════════════╣
 *  TANQUE DE AGUA:
 *   - Capacidad inicial : 1000 litros
 *   - Descuento         : 1 litro cada PASOS_POR_LITRO pasos completos
 *   - Barra LED simula nivel descenso de arriba a abajo
 *   - Al llegar a 0 L → stepper se detiene automáticamente
 * ╚══════════════════════════════════════════════════════════════╝
 */

#include <Wire.h>
#include <LiquidCrystal_AIP31068_I2C.h>
#include <Keypad.h>
#include <DHT.h>
#include <Servo.h>

// ══════════════════════ LCD ══════════════════════════
LiquidCrystal_AIP31068_I2C lcd(0x3E, 16, 2);

// ══════════════════════ DHT22 ════════════════════════
#define DHTPIN  22
#define DHTTYPE DHT22
DHT dht(DHTPIN, DHTTYPE);

// ══════════════════════ LEDS BÁSICOS ═════════════════
const int LED_VERDE = 4;
const int LED_ROJO  = 5;
const int BUZZER    = 13;

// ══════════════════════ LED RGB 1 (riego 1) ══════════
const int RGB1_R = 39;
const int RGB1_G = 40;
const int RGB1_B = 41;

// ══════════════════════ LED RGB 2 (riego 2 / estado) ═
const int RGB2_R = 42;
const int RGB2_G = 43;
const int RGB2_B = 44;

// ══════════════════════ BARRA LED 1 (8 pines) ════════
// Pines de arriba (índice 0) a abajo (índice 7)
const int BARRA1[8] = {23, 24, 25, 26, 27, 28, 29, 30};

// ══════════════════════ BARRA LED 2 (8 pines) ════════
const int BARRA2[8] = {45, 46, 47, 48, 49, 50, 51, 52};

// ══════════════════════ HC-SR04 ══════════════════════
const int TRIG_PIN      = 54;
const int ECHO_PIN      = 55;
const int DIST_ALERTA   = 100;   // cm

// ══════════════════════ SERVO ════════════════════════
Servo ventilacion;
const int PIN_SERVO     = 53;
bool      ventiON       = false;

// ══════════════════════ STEPPERS ═════════════════════
//  Secuencia medio paso 8 pasos — mayor torque
const int S1[4] = {31, 32, 33, 34};
const int S2[4] = {35, 36, 37, 38};

const int SEQ[8][4] = {
  {1,0,0,0}, {1,1,0,0}, {0,1,0,0}, {0,1,1,0},
  {0,0,1,0}, {0,0,1,1}, {0,0,0,1}, {1,0,0,1}
};

int           paso1  = 0,  paso2  = 0;
unsigned long tP1    = 0,  tP2    = 0;
const int     VEL    = 2;          // ms entre pasos
bool          r1ON   = false;      // stepper 1 activo
bool          r2ON   = false;      // stepper 2 activo

// ══════════════════════ TANQUE DE AGUA ═══════════════
float         litros          = 1000.0;  // litros iniciales
const float   LITROS_MAX      = 1000.0;
// Cuántos pasos de stepper equivalen a 1 litro
// Ajustar según el caudal real de la bomba
const int     PASOS_POR_LITRO = 512;
int           contadorPasos1  = 0;       // pasos acumulados stepper 1
int           contadorPasos2  = 0;       // pasos acumulados stepper 2

// ══════════════════════ ANIMACIÓN BARRA LED ══════════
// ledActivo: qué LED de la barra está encendido (0=arriba, 7=abajo)
int           ledBarra1 = 0;
int           ledBarra2 = 0;
unsigned long tAnimBarra1 = 0;
unsigned long tAnimBarra2 = 0;
const int     T_ANIM_BARRA = 150;  // ms entre pasos de animación

// Tonos de confirmación de riego activo
unsigned long tTonoRiego = 0;
bool          tonoRiegoActivo = false;

// ══════════════════════ TECLADO ══════════════════════
const byte FILAS    = 4;
const byte COLS     = 3;
char mapa[FILAS][COLS] = {
  {'1','2','3'},
  {'4','5','6'},
  {'7','8','9'},
  {'*','0','#'}
};
byte pF[FILAS] = {6, 7, 8, 9};
byte pC[COLS]  = {10, 11, 12};
Keypad teclado = Keypad(makeKeymap(mapa), pF, pC, FILAS, COLS);

// ══════════════════════ ESTADOS ══════════════════════
enum EstSistema { ST_CLAVE, ST_MENU, ST_AUTO, ST_MANUAL, ST_RIEGO_SUB };
EstSistema estado = ST_CLAVE;

enum VistaM {
  VM_MENU, VM_TEMP, VM_HUM_AMB, VM_HUM_SUELO,
  VM_SISTEMA, VM_LITROS
};
VistaM vistaM = VM_MENU;

// ══════════════════════ VARIABLES SISTEMA ════════════
String passOK  = "1234";
String passIn  = "";
String passOc  = "";

bool horarioOK    = false;
bool barraManON   = false;
bool alarmaTemp   = false;
bool alarmaSeg    = false;

// Timers
unsigned long tLCD     = 0;
unsigned long tSens    = 0;
unsigned long tSeg     = 0;
const unsigned long T_LCD_AUTO = 2500;
const unsigned long T_SENS     = 500;
const unsigned long T_SEG_INT  = 3000;

int panAuto = 0;   // pantalla rotativa en modo AUTO

// Caché sensores
float cTemp = 0, cHumAmb = 0;
int   cSuelo = 0, cLluvia = 0, cNivelAgua = 0, cLuz = 0;
long  cDist  = 999;

// Flags
bool fSeco    = false;
bool fNoLluv  = false;
bool fAgua    = false;   // sensor tanque físico
bool fPocaLuz = false;
bool fIntruso = false;

// ════════════════════════════════════════════════════
//  SETUP
// ════════════════════════════════════════════════════
void setup() {
  Serial.begin(9600);
  Wire.begin();
  lcd.init();
 
  dht.begin();

  // Pines salida básicos
  pinMode(LED_VERDE, OUTPUT);
  pinMode(LED_ROJO,  OUTPUT);
  pinMode(BUZZER,    OUTPUT);

  // LEDs RGB
  pinMode(RGB1_R, OUTPUT); pinMode(RGB1_G, OUTPUT); pinMode(RGB1_B, OUTPUT);
  pinMode(RGB2_R, OUTPUT); pinMode(RGB2_G, OUTPUT); pinMode(RGB2_B, OUTPUT);
  setRGB1(0,0,0);
  setRGB2(0,0,0);

  // Barras LED
  for (int i = 0; i < 8; i++) {
    pinMode(BARRA1[i], OUTPUT); digitalWrite(BARRA1[i], LOW);
    pinMode(BARRA2[i], OUTPUT); digitalWrite(BARRA2[i], LOW);
  }

  // HC-SR04
  pinMode(TRIG_PIN, OUTPUT);
  pinMode(ECHO_PIN, INPUT);

  // Servo
  ventilacion.attach(PIN_SERVO);
  ventilacion.write(0);

  // Steppers
  for (int i = 0; i < 4; i++) {
    pinMode(S1[i], OUTPUT); digitalWrite(S1[i], LOW);
    pinMode(S2[i], OUTPUT); digitalWrite(S2[i], LOW);
  }

  // Bienvenida
  lcd.print("  INVERNADERO  ");
  lcd.setCursor(0,1);
  lcd.print(" Smart  v3.0   ");
  // Animación de bienvenida: barra 1 de arriba a abajo
  for (int i = 0; i < 8; i++) {
    digitalWrite(BARRA1[i], HIGH);
    digitalWrite(BARRA2[7-i], HIGH);
    delay(120);
  }
  delay(500);
  apagaBarra1();
  apagaBarra2();
  delay(500);
  lcd.clear();
  lcd.print("Ingrese clave:");
}

// ════════════════════════════════════════════════════
//  LOOP PRINCIPAL
// ════════════════════════════════════════════════════
void loop() {
  char t = teclado.getKey();

  // Steppers — tick no bloqueante en cada ciclo
  tickS1();
  tickS2();

  // Animación barra LED si riego activo
  animarBarra1();
  animarBarra2();

  // Tono periódico mientras riego esté activo
  tonoRiegoActivo = (r1ON || r2ON);
  if (tonoRiegoActivo && millis() - tTonoRiego > 1500) {
    tTonoRiego = millis();
    tone(BUZZER, 880, 80);    // pip corto: señal de bomba activa
  }

  // Lectura periódica de sensores
  if (millis() - tSens >= T_SENS) {
    tSens = millis();
    leerSensores();
  }

  switch (estado) {

    case ST_CLAVE:
      if (t) procesarPassword(t);
      break;

    case ST_MENU:
      if (t == '1') { estado = ST_MANUAL; vistaM = VM_MENU; mostrarMenuManual(); }
      if (t == '2') { estado = ST_AUTO;   mostrarInicioAuto(); }
      break;

    case ST_AUTO:
      if (t == '#') { irAlMenu(); break; }
      if (t == '*') { estado = ST_MANUAL; vistaM = VM_MENU; mostrarMenuManual(); break; }
      logicaAuto();
      controlarSeguridad();
      rotarLCDAuto();
      break;

    case ST_MANUAL:
      if (t == '#') { irAlMenu(); break; }
      procesarTecladoManual(t);
      controlarSeguridad();
      alarmaTemperaturaCritica();
      actualizarLCDManual();
      break;

    // Sub-menú de riego: espera '1' o '2'
    case ST_RIEGO_SUB:
      if (t == '1') { activarRiego();    estado = ST_MANUAL; }
      if (t == '2') { desactivarRiego(); estado = ST_MANUAL; }
      if (t == '#' || t == '0') { estado = ST_MANUAL; vistaM = VM_MENU; mostrarMenuManual(); }
      break;
  }
}

// ════════════════════════════════════════════════════
//  LECTURA DE SENSORES
// ════════════════════════════════════════════════════
void leerSensores() {
  float tt = dht.readTemperature();
  float hh = dht.readHumidity();
  if (!isnan(tt)) cTemp   = tt;
  if (!isnan(hh)) cHumAmb = hh;

  cSuelo     = analogRead(A0);
  cLluvia    = analogRead(A1);
  cNivelAgua = analogRead(A2);
  cLuz       = analogRead(A3);
  cDist      = medirDistancia();

  fSeco    = (cSuelo > 700);
  fNoLluv  = (cLluvia > 500);
  fAgua    = (cNivelAgua > 300) && (litros > 0);
  fPocaLuz = (cLuz < 400);
  fIntruso = (cDist > 0 && cDist < DIST_ALERTA);
}

// ════════════════════════════════════════════════════
//  LÓGICA AUTOMÁTICA
//  Cada actuador se activa SOLO si se cumplen
//  MÚLTIPLES condiciones simultáneamente
// ════════════════════════════════════════════════════
void logicaAuto() {

  // ── 1. RIEGO ────────────────────────────────────
  // CONDICIÓN: suelo seco  AND  no llueve  AND  hay agua  AND  litros > 0
  if (fSeco && fNoLluv && fAgua && litros > 0) {
    r1ON = true;
    setRGB1(0, 0, 255);           // Azul → regando
    setRGB2(0, 0, 200);
    digitalWrite(LED_VERDE, HIGH);
  }
  else if (!fSeco) {
    if (r1ON) desactivarRiego();
    setRGB1(0, 255, 0);           // Verde → suelo húmedo OK
    setRGB2(0, 200, 0);
    digitalWrite(LED_VERDE, HIGH);
  }
  else if (!fNoLluv) {
    if (r1ON) desactivarRiego();
    setRGB1(0, 150, 255);         // Celeste → lluvia detectada
    setRGB2(0, 100, 255);
  }
  else {
    // sin agua
    if (r1ON) desactivarRiego();
    setRGB1(255, 0, 0);           // Rojo → sin agua
    setRGB2(255, 0, 0);
    parpadeoLEDRojo(1);
  }

  // ── 2. VENTILACIÓN ──────────────────────────────
  // CONDICIÓN: temperatura alta (servo escalonado)
  controlarVentilacionPorTemp();

  // ── 3. ALARMA TEMP CRÍTICA ───────────────────────
  alarmaTemperaturaCritica();

  // ── 4. ILUMINACIÓN (barra LED en auto) ──────────
  // CONDICIÓN: poca luz  AND  modo AUTO  AND  riego NO activo
  // (si riego activo, la barra ya está en animación de riego)
  if (!r1ON && !r2ON) {
    if (fPocaLuz) {
      // Encender todas las barras
      for (int i = 0; i < 8; i++) {
        digitalWrite(BARRA1[i], HIGH);
        digitalWrite(BARRA2[i], HIGH);
      }
    } else {
      apagaBarra1();
      apagaBarra2();
    }
  }
}

// ════════════════════════════════════════════════════
//  CONTROL DE VENTILACIÓN POR TEMPERATURA
// ════════════════════════════════════════════════════
void controlarVentilacionPorTemp() {
  // CONDICIÓN: temperatura determina apertura del servo
  if      (cTemp < 25) ventilacion.write(0);
  else if (cTemp < 28) ventilacion.write(60);
  else if (cTemp < 32) ventilacion.write(120);
  else                 ventilacion.write(180);
}

// ════════════════════════════════════════════════════
//  ALARMA TEMPERATURA CRÍTICA
// ════════════════════════════════════════════════════
void alarmaTemperaturaCritica() {
  // CONDICIÓN: fuera de rango seguro
  if (cTemp > 35 || (cTemp < 12 && cTemp > 0)) {
    alarmaTemp = true;
    digitalWrite(LED_ROJO, HIGH);
    if (!alarmaSeg) tone(BUZZER, 600);  // alarma sostenida
  } else {
    if (alarmaTemp) {
      alarmaTemp = false;
      if (!alarmaSeg) {
        noTone(BUZZER);
        digitalWrite(LED_ROJO, LOW);
      }
    }
  }
}

// ════════════════════════════════════════════════════
//  SEGURIDAD HC-SR04
//  CONDICIÓN: intrusión detectada  AND  fuera de horario
// ════════════════════════════════════════════════════
void controlarSeguridad() {
  if (fIntruso && !horarioOK) {
    if (millis() - tSeg > T_SEG_INT) {
      tSeg       = millis();
      alarmaSeg  = true;

      lcd.clear();
      lcd.print("!! INTRUSO !!");
      lcd.setCursor(0,1);
      lcd.print("Dist:");
      lcd.print(cDist);
      lcd.print("cm");

      tone(BUZZER, 1400, 100); delay(130);
      tone(BUZZER, 1100, 100); delay(130);
      tone(BUZZER, 1400, 100); delay(130);
      noTone(BUZZER);

      for (int i = 0; i < 3; i++) {
        digitalWrite(LED_ROJO, HIGH); delay(80);
        digitalWrite(LED_ROJO, LOW);  delay(80);
      }
      tLCD = 0;  // fuerza refresco LCD
    }
  } else {
    alarmaSeg = false;
    if (!alarmaTemp) {
      noTone(BUZZER);
      digitalWrite(LED_ROJO, LOW);
    }
  }
}

// ════════════════════════════════════════════════════
//  ACTIVAR / DESACTIVAR RIEGO (manual y auto)
// ════════════════════════════════════════════════════
void activarRiego() {
  if (litros <= 0) {
    lcd.clear();
    lcd.print("SIN AGUA!");
    lcd.setCursor(0,1);
    lcd.print("Tanque vacio");
    tone(BUZZER, 300, 600);
    delay(1500);
    vistaM = VM_MENU;
    mostrarMenuManual();
    return;
  }
  if (!fAgua) {
    lcd.clear();
    lcd.print("Sensor agua:");
    lcd.setCursor(0,1);
    lcd.print("Nivel bajo");
    tone(BUZZER, 300, 600);
    delay(1500);
    vistaM = VM_MENU;
    mostrarMenuManual();
    return;
  }

  r1ON = true;
  r2ON = true;

  // ── LED RGB azul = riego activo ──
  setRGB1(0, 0, 255);
  setRGB2(0, 0, 255);

  // ── Sonido de confirmación ──
  tone(BUZZER, 880, 100); delay(120);
  tone(BUZZER, 1100, 150); delay(170);
  noTone(BUZZER);

  // ── LED Verde ON ──
  digitalWrite(LED_VERDE, HIGH);

  lcd.clear();
  lcd.print("RIEGO ACTIVO");
  lcd.setCursor(0,1);
  lcd.print("Agua:");
  lcd.print((int)litros);
  lcd.print("L");
  tLCD = millis() + 2000;
  vistaM = VM_LITROS;
}

void desactivarRiego() {
  r1ON = false;
  r2ON = false;

  for (int i = 0; i < 4; i++) {
    digitalWrite(S1[i], LOW);
    digitalWrite(S2[i], LOW);
  }

  // ── LED RGB apagado ──
  setRGB1(0, 0, 0);
  setRGB2(0, 0, 0);

  // Barra LED apagada
  apagaBarra1();
  apagaBarra2();

  // Sonido de apagado
  tone(BUZZER, 600, 100); delay(120);
  tone(BUZZER, 400, 150); delay(170);
  noTone(BUZZER);

  digitalWrite(LED_VERDE, LOW);

  lcd.clear();
  lcd.print("RIEGO DETENIDO");
  lcd.setCursor(0,1);
  lcd.print("Agua:");
  lcd.print((int)litros);
  lcd.print("L");
  delay(1500);
  vistaM = VM_MENU;
  mostrarMenuManual();
}

// ════════════════════════════════════════════════════
//  TECLADO MODO MANUAL
// ════════════════════════════════════════════════════
void procesarTecladoManual(char t) {
  if (!t) return;

  switch (t) {
    case '1': vistaM = VM_TEMP;      lcd.clear(); break;
    case '2': vistaM = VM_HUM_AMB;   lcd.clear(); break;
    case '3': vistaM = VM_HUM_SUELO; lcd.clear(); break;
    case '4': vistaM = VM_SISTEMA;   lcd.clear(); break;
    case '9': vistaM = VM_LITROS;    lcd.clear(); break;
    case '0': vistaM = VM_MENU;      mostrarMenuManual(); break;

    // ── Submenú RIEGO ──────────────────────────────
    case '5':
      estado = ST_RIEGO_SUB;
      lcd.clear();
      lcd.print("RIEGO:");
      lcd.setCursor(0,1);
      lcd.print("1=ON  2=OFF  #=X");
      break;

    // ── Ventilación ────────────────────────────────
    // CONDICIÓN MANUAL: usuario controla libremente
    case '6':
      ventiON = !ventiON;
      ventilacion.write(ventiON ? 180 : 0);
      lcd.clear();
      lcd.print("Ventilacion:");
      lcd.setCursor(0,1);
      lcd.print(ventiON ? "ABIERTA " : "CERRADA ");
      tLCD = millis() + 800;
      break;

    // ── Barra LED manual ───────────────────────────
    case '7':
      barraManON = !barraManON;
      if (barraManON) {
        for (int i=0;i<8;i++) { digitalWrite(BARRA1[i],HIGH); digitalWrite(BARRA2[i],HIGH); }
      } else {
        apagaBarra1(); apagaBarra2();
      }
      lcd.clear();
      lcd.print("Barra LED:");
      lcd.setCursor(0,1);
      lcd.print(barraManON ? "ENCENDIDA" : "APAGADA  ");
      tLCD = millis() + 800;
      break;

    // ── Horario seguridad ──────────────────────────
    case '8':
      horarioOK = !horarioOK;
      lcd.clear();
      lcd.print("Horario:");
      lcd.setCursor(0,1);
      lcd.print(horarioOK ? "PERMITIDO   " : "RESTRINGIDO ");
      tLCD = millis() + 1000;
      break;
  }
}

// ════════════════════════════════════════════════════
//  LCD MODO MANUAL
// ════════════════════════════════════════════════════
void actualizarLCDManual() {
  if (millis() - tLCD < 700) return;
  tLCD = millis();
  if (millis() - tSeg < 2500) return;   // no sobreescribir alerta

  switch (vistaM) {

    case VM_MENU:
      // El menú ya fue impreso, no sobreescribir
      break;

    case VM_TEMP:
      lcd.setCursor(0,0);
      lcd.print("Temperatura:    ");
      lcd.setCursor(0,1);
      lcd.print(cTemp,1);
      lcd.print("\xDF""C ");
      lcd.print(cTemp>35?"!ALTA!": cTemp<12?"!BAJA!": "  OK  ");
      break;

    case VM_HUM_AMB:
      lcd.setCursor(0,0);
      lcd.print("Hum. Ambiente:  ");
      lcd.setCursor(0,1);
      lcd.print(cHumAmb,0);
      lcd.print("%              ");
      break;

    case VM_HUM_SUELO:
      lcd.setCursor(0,0);
      lcd.print("Hum. Suelo:     ");
      lcd.setCursor(0,1);
      lcd.print(fSeco ? "SECO  " : "HUMEDO");
      lcd.print(" ");
      lcd.print(cSuelo);
      lcd.print("   ");
      break;

    case VM_SISTEMA:
      lcd.setCursor(0,0);
      lcd.print("Rg:");
      lcd.print(r1ON?"ON ":"OFF");
      lcd.print(" Vt:");
      lcd.print(ventiON?"ON ":"OFF");
      lcd.setCursor(0,1);
      lcd.print("Lz:");
      lcd.print(barraManON?"ON ":"OFF");
      lcd.print(" H2O:");
      lcd.print((int)litros);
      lcd.print("L");
      break;

    case VM_LITROS:
      lcd.setCursor(0,0);
      lcd.print("Agua restante:  ");
      lcd.setCursor(0,1);
      lcd.print((int)litros);
      lcd.print(" / ");
      lcd.print((int)LITROS_MAX);
      lcd.print(" L     ");
      // Barra visual proporcional en segunda línea (caracteres llenos)
      // Representación extra con LED verde/rojo
      if      (litros > 600) digitalWrite(LED_VERDE, HIGH);
      else if (litros > 200) { digitalWrite(LED_VERDE, HIGH); digitalWrite(LED_ROJO, HIGH); }
      else                   { digitalWrite(LED_VERDE, LOW);  digitalWrite(LED_ROJO, HIGH); }
      break;
  }
}

// ════════════════════════════════════════════════════
//  LCD MODO AUTOMÁTICO (rotación 4 pantallas)
// ════════════════════════════════════════════════════
void rotarLCDAuto() {
  if (millis() - tLCD < T_LCD_AUTO) return;
  tLCD = millis();
  if (millis() - tSeg < 2500) return;

  lcd.clear();
  switch (panAuto) {
    case 0:
      lcd.print("T:");
      lcd.print(cTemp,1);
      lcd.print("\xDF""C ");
      lcd.print(cTemp>35?"!ALT!": cTemp<12?"!BAJ!":"     ");
      lcd.setCursor(0,1);
      lcd.print("HAmb:");
      lcd.print(cHumAmb,0);
      lcd.print("% ");
      break;

    case 1:
      lcd.print("Suelo:");
      lcd.print(fSeco?"SECO  ":"HUMEDO");
      lcd.setCursor(0,1);
      lcd.print("Lluvia:");
      lcd.print(fNoLluv?"NO ":"SI ");
      lcd.print("H2O:");
      lcd.print(fAgua?"SI":"NO");
      break;

    case 2:
      lcd.print("Luz:");
      lcd.print(cLuz);
      lcd.print(fPocaLuz?" BAJA ":" OK   ");
      lcd.setCursor(0,1);
      lcd.print("Servo:");
      lcd.print(cTemp<25?"0% ": cTemp<28?"33%": cTemp<32?"66%":"100%");
      break;

    case 3:
      lcd.print("AUTO Agua:");
      lcd.print((int)litros);
      lcd.print("L ");
      lcd.setCursor(0,1);
      lcd.print("Rg:");
      if      (r1ON)      lcd.print("ACTIVO ");
      else if (!fAgua)    lcd.print("SIN H2O");
      else if (!fNoLluv)  lcd.print("LLUVIA ");
      else                lcd.print("ESPERA ");
      break;
  }
  panAuto = (panAuto+1) % 4;
}

// ════════════════════════════════════════════════════
//  STEPPER 1 — tick no bloqueante + descuento de litros
// ════════════════════════════════════════════════════
void tickS1() {
  if (!r1ON) return;
  if (litros <= 0) { desactivarRiego(); return; }
  if (millis() - tP1 < VEL) return;
  tP1 = millis();

  for (int i=0; i<4; i++) digitalWrite(S1[i], SEQ[paso1][i]);
  paso1 = (paso1+1) % 8;

  contadorPasos1++;
  if (contadorPasos1 >= PASOS_POR_LITRO) {
    contadorPasos1 = 0;
    litros -= 1.0;
    if (litros < 0) litros = 0;
  }
}

// ════════════════════════════════════════════════════
//  STEPPER 2 — tick no bloqueante + descuento de litros
// ════════════════════════════════════════════════════
void tickS2() {
  if (!r2ON) return;
  if (litros <= 0) { desactivarRiego(); return; }
  if (millis() - tP2 < VEL) return;
  tP2 = millis();

  for (int i=0; i<4; i++) digitalWrite(S2[i], SEQ[paso2][i]);
  paso2 = (paso2+1) % 8;

  contadorPasos2++;
  if (contadorPasos2 >= PASOS_POR_LITRO) {
    contadorPasos2 = 0;
    litros -= 1.0;
    if (litros < 0) litros = 0;
  }
}

// ════════════════════════════════════════════════════
//  ANIMACIÓN BARRA LED 1 (de arriba a abajo = riego cayendo)
// ════════════════════════════════════════════════════
void animarBarra1() {
  if (!r1ON) return;
  if (millis() - tAnimBarra1 < T_ANIM_BARRA) return;
  tAnimBarra1 = millis();

  apagaBarra1();
  digitalWrite(BARRA1[ledBarra1], HIGH);
  ledBarra1 = (ledBarra1+1) % 8;
}

void apagaBarra1() {
  for (int i=0; i<8; i++) digitalWrite(BARRA1[i], LOW);
}

// ════════════════════════════════════════════════════
//  ANIMACIÓN BARRA LED 2
// ════════════════════════════════════════════════════
void animarBarra2() {
  if (!r2ON) return;
  if (millis() - tAnimBarra2 < T_ANIM_BARRA) return;
  tAnimBarra2 = millis();

  apagaBarra2();
  digitalWrite(BARRA2[ledBarra2], HIGH);
  ledBarra2 = (ledBarra2+1) % 8;
}

void apagaBarra2() {
  for (int i=0; i<8; i++) digitalWrite(BARRA2[i], LOW);
}

// ════════════════════════════════════════════════════
//  HC-SR04 — medir distancia
// ════════════════════════════════════════════════════
long medirDistancia() {
  digitalWrite(TRIG_PIN, LOW);
  delayMicroseconds(2);
  digitalWrite(TRIG_PIN, HIGH);
  delayMicroseconds(10);
  digitalWrite(TRIG_PIN, LOW);
  long d = pulseIn(ECHO_PIN, HIGH, 25000);
  if (d == 0) return 999;
  return d * 0.0343 / 2;
}

// ════════════════════════════════════════════════════
//  PASSWORD
// ════════════════════════════════════════════════════
void procesarPassword(char t) {
  if (t == '*') {
    passIn = ""; passOc = "";
    lcd.setCursor(0,1);
    lcd.print("                ");
    return;
  }
  passIn += t;
  passOc += "*";
  lcd.setCursor(0,1);
  lcd.print(passOc);

  if (passIn.length() == 4) {
    if (passIn == passOK) {
      lcd.clear();
      lcd.print("  Acceso OK!  ");
      digitalWrite(LED_VERDE, HIGH);
      tone(BUZZER, 880, 150); delay(180);
      tone(BUZZER, 1100, 200); delay(220);
      noTone(BUZZER);
      delay(600);
      digitalWrite(LED_VERDE, LOW);
      estado = ST_MENU;
      lcd.clear();
      lcd.print("1.Manual 2.Auto");
      lcd.setCursor(0,1);
      lcd.print("Seleccione modo");
    } else {
      lcd.clear();
      lcd.print(" Clave Erronea ");
      tone(BUZZER, 200, 500);
      delay(1000);
      lcd.clear();
      lcd.print("Ingrese clave:");
    }
    passIn = ""; passOc = "";
  }
}

// ════════════════════════════════════════════════════
//  HELPERS DE INTERFAZ
// ════════════════════════════════════════════════════
void irAlMenu() {
  r1ON = false; r2ON = false;
  for (int i=0;i<4;i++) { digitalWrite(S1[i],LOW); digitalWrite(S2[i],LOW); }
  ventilacion.write(0);
  apagaBarra1(); apagaBarra2();
  setRGB1(0,0,0); setRGB2(0,0,0);
  ventiON = false; barraManON = false;
  noTone(BUZZER);
  digitalWrite(LED_VERDE, LOW);
  digitalWrite(LED_ROJO,  LOW);

  estado = ST_MENU;
  lcd.clear();
  lcd.print("1.Manual 2.Auto");
  lcd.setCursor(0,1);
  lcd.print("Seleccione modo");
}

void mostrarMenuManual() {
  lcd.clear();
  lcd.print("1T 2H 3S 4Est 9A");
  lcd.setCursor(0,1);
  lcd.print("5Rg 6Vt 7Lz 8Hr");
  tLCD = millis() + 3000;
}

void mostrarInicioAuto() {
  lcd.clear();
  lcd.print("Modo: AUTOMATICO");
  lcd.setCursor(0,1);
  lcd.print("*=Manual  #=Menu");
  delay(1400);
  lcd.clear();
}

void setRGB1(int r, int g, int b) {
  analogWrite(RGB1_R, r);
  analogWrite(RGB1_G, g);
  analogWrite(RGB1_B, b);
}

void setRGB2(int r, int g, int b) {
  analogWrite(RGB2_R, r);
  analogWrite(RGB2_G, g);
  analogWrite(RGB2_B, b);
}

void parpadeoLEDRojo(int n) {
  for (int i=0;i<n;i++) {
    digitalWrite(LED_ROJO, HIGH); delay(70);
    digitalWrite(LED_ROJO, LOW);  delay(70);
  }
}
