import numpy as np
import matplotlib.pyplot as plt
import cv2

# ==================================
# GENERAR TEMPERATURAS SIMULADAS
# ==================================

temperaturas = np.random.normal(
    loc=20,      # temperatura promedio
    scale=4,     # variación
    size=50      # cantidad de muestras
)

# ==================================
# MOSTRAR ALERTAS
# ==================================

print("\nMONITOREO DE TEMPERATURA\n")

for i, temp in enumerate(temperaturas):

    if temp > 25:

        print(
            f"Muestra {i+1}: "
            f"{temp:.2f}°C -> ALERTA"
        )

    else:

        print(
            f"Muestra {i+1}: "
            f"{temp:.2f}°C -> NORMAL"
        )

# ==================================
# GRAFICO DE TEMPERATURA
# ==================================

plt.figure(figsize=(10,5))

plt.plot(
    temperaturas,
    marker="o"
)

plt.axhline(
    y=25,
    linestyle="--",
    label="Límite Máximo"
)

plt.title(
    "Monitoreo de Temperatura"
)

plt.xlabel(
    "Tiempo"
)

plt.ylabel(
    "Temperatura (°C)"
)

plt.legend()

plt.grid(True)

plt.show()

# ==================================
# OPENCV
# ==================================

ultima_temp = temperaturas[-1]

imagen = np.zeros(
    (400, 700, 3),
    dtype=np.uint8
)

cv2.putText(
    imagen,
    "ALMACEN DE PERECEDEROS",
    (100, 80),
    cv2.FONT_HERSHEY_SIMPLEX,
    1,
    (255,255,255),
    2
)

cv2.putText(
    imagen,
    f"Temperatura: {ultima_temp:.2f} C",
    (120,180),
    cv2.FONT_HERSHEY_SIMPLEX,
    1,
    (0,255,255),
    2
)

if ultima_temp > 25:

    mensaje = "ALERTA"

    color = (0,0,255)

else:

    mensaje = "NORMAL"

    color = (0,255,0)

cv2.putText(
    imagen,
    mensaje,
    (250,300),
    cv2.FONT_HERSHEY_SIMPLEX,
    1.5,
    color,
    3
)

cv2.imshow(
    "Sistema de Monitoreo",
    imagen
)

cv2.waitKey(0)

cv2.destroyAllWindows()