const URL = "./modelo/";

let model, webcam, labelContainer, maxPredictions;

async function init() {

    try {

        const modelURL = URL + "model.json";
        const metadataURL = URL + "metadata.json";

        model = await tmImage.load(modelURL, metadataURL);

        maxPredictions = model.getTotalClasses();

        webcam = new tmImage.Webcam(300, 300, true);

        // Configurar cámara
        await webcam.setup();

        // Reproducir cámara
        await webcam.play();

        window.requestAnimationFrame(loop);

        document.getElementById("webcam-container")
            .appendChild(webcam.canvas);

        labelContainer = document.getElementById("label-container");

        for (let i = 0; i < maxPredictions; i++) {

            labelContainer.appendChild(
                document.createElement("div")
            );
        }

    } catch (error) {

        console.error("ERROR:", error);

        alert("No se pudo iniciar la cámara");
    }
}

async function loop() {

    webcam.update();

    await predict();

    window.requestAnimationFrame(loop);
}

async function predict() {

    const prediction = await model.predict(webcam.canvas);

    for (let i = 0; i < maxPredictions; i++) {

        const classPrediction =
            prediction[i].className + ": " +
            (prediction[i].probability * 100).toFixed(2) + "%";

        labelContainer.childNodes[i].innerHTML =
            classPrediction;
    }
}
// =====================================
// OPERACION 1
// =====================================

document.getElementById(
    "temp-op1"
).innerHTML = "27°C";

document.getElementById(
    "estado-op1"
).innerHTML = "ALERTA";

// =====================================
// OPERACION 2
// =====================================

document.getElementById(
    "prediccion-op2"
).innerHTML = "80.6°F";

// =====================================
// OPERACION 3
// =====================================

document.getElementById(
    "estado-op3"
).innerHTML = "Activo";

document.getElementById(
    "alerta-op3"
).innerHTML =
    "Temperatura superior a 25°C";