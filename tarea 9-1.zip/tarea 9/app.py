from flask import Flask, render_template, jsonify
import random

app = Flask(__name__)

@app.route("/")
def inicio():
    return render_template("index.html")

@app.route("/datos")
def datos():

    temperatura = random.randint(18,35)

    return jsonify({

        "temperatura": temperatura,

        "estado":
            "ALERTA" if temperatura > 25
            else "NORMAL",

        "prediccion":
            temperatura * 1.8 + 32,

        "tinyml":
            "ACTIVO"
    })

app.run(debug=True)