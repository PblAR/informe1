# =====================================================
# PREDICCIÓN DE PRECIO DE CELULARES CON IA
# Versión completa: imágenes + reconocimiento + sliders
# =====================================================

# =====================================================
# INSTALACIONES NECESARIAS (ejecutar primero en Colab)
# =====================================================
# !pip install tensorflow pillow ipywidgets

# =====================================================
# PASO 1: IMPORTAR LIBRERÍAS
# =====================================================

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
import requests
import warnings
warnings.filterwarnings("ignore")

from io import BytesIO
from PIL import Image

from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_absolute_error, r2_score

import ipywidgets as widgets
from IPython.display import display, clear_output, HTML

# =====================================================
# PASO 2: CREAR LOS DATOS
# =====================================================

datos = {
    "ram":            [2,  3,  4,   4,   6,   6,   8,   8,   12,  12,  16,   16,   8,   4,   6 ],
    "almacenamiento": [32, 64, 64,  128, 128, 256, 128, 256, 256, 512, 512,  1024, 512, 128, 256],
    "camara":         [8,  12, 13,  48,  48,  64,  64,  108, 108, 200, 200,  250,  108, 50,  64 ],
    "bateria":        [3000,3500,4000,4500,5000,5000,5000,5500,6000,6000,6000,6500,5500,4500,5000],
    "marca_valor":    [1,  1,  1,   2,   2,   2,   2,   3,   3,   3,   3,    3,    3,   2,   2  ],
    "precio":         [350,450,600,750,950,1150,1300,1600,2200,3000,3800,4500,1800,850,1200]
}

df = pd.DataFrame(datos)

# =====================================================
# PASO 3: ENTRENAR EL MODELO
# =====================================================

X = df[["ram","almacenamiento","camara","bateria","marca_valor"]]
y = df["precio"]

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42
)

modelo_precio = LinearRegression()
modelo_precio.fit(X_train, y_train)

predicciones = modelo_precio.predict(X_test)
mae       = mean_absolute_error(y_test, predicciones)
precision = r2_score(y_test, predicciones)

print("✅ Modelo de precios entrenado")
print(f"   Precisión R²   : {precision:.4f}")
print(f"   Error promedio : S/. {mae:.2f}")

# =====================================================
# PASO 4: IMÁGENES DE CELULARES CON MATPLOTLIB
# Descarga imágenes de ejemplo desde URLs públicas
# y las muestra en una cuadrícula con su rango de precio
# =====================================================

celulares_info = [
    {
        "marca"  : "Samsung Galaxy A",
        "tipo"   : "Intermedia",
        "specs"  : "8GB · 256GB · 108MP",
        "precio" : "S/. 1,300 – 1,600",
        "color"  : "#1428A0",
        "url"    : "https://upload.wikimedia.org/wikipedia/commons/thumb/2/24/Samsung_Logo.svg/300px-Samsung_Logo.svg.png"
    },
    {
        "marca"  : "Xiaomi Redmi",
        "tipo"   : "Económica",
        "specs"  : "4GB · 128GB · 48MP",
        "precio" : "S/. 600 – 900",
        "color"  : "#FF6900",
        "url"    : "https://upload.wikimedia.org/wikipedia/commons/thumb/2/29/Xiaomi_logo.svg/300px-Xiaomi_logo.svg.png"
    },
    {
        "marca"  : "iPhone",
        "tipo"   : "Premium",
        "specs"  : "8GB · 512GB · 200MP",
        "precio" : "S/. 3,000 – 4,500",
        "color"  : "#555555",
        "url"    : "https://upload.wikimedia.org/wikipedia/commons/thumb/f/fa/Apple_logo_black.svg/200px-Apple_logo_black.svg.png"
    },
    {
        "marca"  : "Motorola Moto G",
        "tipo"   : "Económica",
        "specs"  : "4GB · 128GB · 50MP",
        "precio" : "S/. 500 – 800",
        "color"  : "#5D2D91",
        "url"    : "https://upload.wikimedia.org/wikipedia/commons/thumb/8/8a/Motorola_logo_2014.svg/300px-Motorola_logo_2014.svg.png"
    },
]

def mostrar_galeria_celulares():
    fig, axes = plt.subplots(2, 2, figsize=(12, 8))
    fig.patch.set_facecolor("#f8f9fa")
    fig.suptitle("Galería de Marcas de Celulares", fontsize=16, fontweight="bold", y=1.01)

    for ax, cel in zip(axes.flatten(), celulares_info):
        try:
            resp = requests.get(cel["url"], timeout=5)
            img  = Image.open(BytesIO(resp.content)).convert("RGBA")

            fondo = Image.new("RGBA", img.size, (255, 255, 255, 255))
            fondo.paste(img, mask=img.split()[3])
            img_final = fondo.convert("RGB")

            ax.imshow(img_final)
        except Exception:
            ax.set_facecolor(cel["color"] + "22")
            ax.text(0.5, 0.5, cel["marca"][0],
                    transform=ax.transAxes,
                    ha="center", va="center",
                    fontsize=48, fontweight="bold",
                    color=cel["color"])

        tipo_color = {"Premium": "#c0392b", "Intermedia": "#2980b9", "Económica": "#27ae60"}
        color_badge = tipo_color.get(cel["tipo"], "#555")

        ax.set_title(
            f"{cel['marca']}\n{cel['specs']}",
            fontsize=11, fontweight="bold", pad=8
        )
        ax.set_xlabel(
            f"Tipo: {cel['tipo']}    Precio: {cel['precio']}",
            fontsize=9, color=color_badge, fontweight="bold"
        )
        ax.set_xticks([])
        ax.set_yticks([])
        for spine in ax.spines.values():
            spine.set_edgecolor(cel["color"])
            spine.set_linewidth(2)

    plt.tight_layout()
    plt.show()

print("\n📱 Mostrando galería de celulares...")
mostrar_galeria_celulares()


# =====================================================
# PASO 5: RECONOCIMIENTO DE MARCAS CON TENSORFLOW
# Usa un modelo simple de red neuronal entrenado
# con las características numéricas para clasificar
# la marca probable del celular.
# NOTA: En producción usarías Teachable Machine con
# imágenes reales. Aquí entrenamos con los datos
# de specs para demostrar el flujo completo.
# =====================================================

try:
    import tensorflow as tf
    from tensorflow import keras

    print("\n🧠 Entrenando modelo de reconocimiento de marca con TensorFlow...")

    # Datos de entrenamiento para clasificación de marca
    datos_marca = {
        "ram"           : [4,  4,  6,  6,  8,  8,  12, 16, 8,  4,  6,  4,  8,  12, 16],
        "almacenamiento": [128,128,256,256,256,512,512,1024,256,64,128,128,512,256,512],
        "camara"        : [48, 50, 64, 64, 108,200,200,250, 64, 13, 48, 48, 108,108,200],
        "bateria"       : [4500,4500,5000,5000,5500,6000,6000,6500,5000,4000,5000,4500,5500,6000,6000],
        # 0=Samsung, 1=Xiaomi, 2=iPhone, 3=Motorola
        "marca_id"      : [0, 3, 0, 1, 0, 2, 2, 2, 1, 1, 3, 3, 0, 2, 2]
    }
    df_marca = pd.DataFrame(datos_marca)

    X_marca = df_marca[["ram","almacenamiento","camara","bateria"]].values
    y_marca = df_marca["marca_id"].values

    # Normalizar datos (importante para redes neuronales)
    X_min = X_marca.min(axis=0)
    X_max = X_marca.max(axis=0)
    X_norm = (X_marca - X_min) / (X_max - X_min + 1e-8)

    # Construir la red neuronal
    modelo_marca = keras.Sequential([
        keras.layers.Dense(16, activation="relu",    input_shape=(4,)),
        keras.layers.Dense(16, activation="relu"),
        keras.layers.Dense(4,  activation="softmax")
    ])

    modelo_marca.compile(
        optimizer="adam",
        loss="sparse_categorical_crossentropy",
        metrics=["accuracy"]
    )

    historial = modelo_marca.fit(
        X_norm, y_marca,
        epochs=80,
        verbose=0,
        validation_split=0.2
    )

    acc_final = historial.history["accuracy"][-1]
    print(f"   Red neuronal entrenada — precisión: {acc_final:.0%}")

    # Graficar el aprendizaje de la red
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(12, 4))
    fig.suptitle("Aprendizaje de la Red Neuronal", fontsize=14, fontweight="bold")

    ax1.plot(historial.history["accuracy"],     label="Entrenamiento", color="#2980b9")
    ax1.plot(historial.history["val_accuracy"], label="Validación",    color="#e74c3c", linestyle="--")
    ax1.set_title("Precisión por época")
    ax1.set_xlabel("Época")
    ax1.set_ylabel("Precisión")
    ax1.legend()
    ax1.grid(True, alpha=0.3)

    ax2.plot(historial.history["loss"],     label="Entrenamiento", color="#27ae60")
    ax2.plot(historial.history["val_loss"], label="Validación",    color="#e67e22", linestyle="--")
    ax2.set_title("Error (Loss) por época")
    ax2.set_xlabel("Época")
    ax2.set_ylabel("Loss")
    ax2.legend()
    ax2.grid(True, alpha=0.3)

    plt.tight_layout()
    plt.show()

    TENSORFLOW_DISPONIBLE = True
    print("✅ TensorFlow listo para reconocer marcas")

except ImportError:
    TENSORFLOW_DISPONIBLE = False
    print("⚠️  TensorFlow no disponible. Ejecuta: !pip install tensorflow")
    print("   El resto del programa funcionará sin reconocimiento de marca.")


# =====================================================
# PASO 6: INTERFAZ INTERACTIVA CON IPYWIDGETS
# Sliders para ingresar specs y ver precio + marca
# en tiempo real, con gráfico de barras animado.
# =====================================================

print("\n🎛️  Iniciando interfaz interactiva...")

# ── Widgets de entrada ────────────────────────────

titulo = widgets.HTML(
    value="<h2 style='color:#2c3e50;margin:0'>📱 Predictor de Precio de Celulares</h2>"
          "<p style='color:#7f8c8d;margin:4px 0 12px'>Mueve los sliders y ve el precio en tiempo real</p>"
)

w_ram = widgets.IntSlider(
    value=8, min=2, max=16, step=1,
    description="RAM (GB)",
    style={"description_width": "120px"},
    layout=widgets.Layout(width="480px")
)
w_alm = widgets.IntSlider(
    value=256, min=32, max=1024, step=32,
    description="Alm. (GB)",
    style={"description_width": "120px"},
    layout=widgets.Layout(width="480px")
)
w_cam = widgets.IntSlider(
    value=64, min=8, max=250, step=1,
    description="Cámara (MP)",
    style={"description_width": "120px"},
    layout=widgets.Layout(width="480px")
)
w_bat = widgets.IntSlider(
    value=5000, min=3000, max=6500, step=500,
    description="Batería (mAh)",
    style={"description_width": "120px"},
    layout=widgets.Layout(width="480px")
)
w_marca = widgets.RadioButtons(
    options=[("1 – Económica", 1), ("2 – Intermedia", 2), ("3 – Premium", 3)],
    value=2,
    description="Marca:",
    style={"description_width": "120px"}
)

btn_predecir = widgets.Button(
    description="🔍 Predecir precio",
    button_style="primary",
    layout=widgets.Layout(width="200px", height="40px")
)

salida = widgets.Output()

# ── Función principal ─────────────────────────────

def predecir_y_mostrar(b):
    with salida:
        clear_output(wait=True)

        ram    = w_ram.value
        alm    = w_alm.value
        cam    = w_cam.value
        bat    = w_bat.value
        marca  = w_marca.value

        # 1) Predecir precio
        nuevo = pd.DataFrame({
            "ram": [ram], "almacenamiento": [alm],
            "camara": [cam], "bateria": [bat],
            "marca_valor": [marca]
        })
        precio = modelo_precio.predict(nuevo)[0]
        margen = mae

        # 2) Reconocer marca con TensorFlow
        nombre_marcas = {1: "Samsung", 2: "Xiaomi", 3: "iPhone", 4: "Motorola"}
        if TENSORFLOW_DISPONIBLE:
            x_nuevo = np.array([[ram, alm, cam, bat]], dtype=float)
            x_norm  = (x_nuevo - X_min) / (X_max - X_min + 1e-8)
            probs   = modelo_marca.predict(x_norm, verbose=0)[0]
            marcas  = ["Samsung", "Xiaomi", "iPhone", "Motorola"]
            marca_pred = marcas[np.argmax(probs)]
            confianza  = probs.max()
        else:
            marcas     = ["Samsung", "Xiaomi", "iPhone", "Motorola"]
            probs      = np.array([0.25, 0.25, 0.25, 0.25])
            marca_pred = "—"
            confianza  = 0.0

        tipo_marca = {1: "Económica", 2: "Intermedia", 3: "Premium"}[marca]
        color_tipo = {"Premium": "#c0392b", "Intermedia": "#2980b9", "Económica": "#27ae60"}[tipo_marca]

        # 3) Figura con 3 paneles
        fig, axes = plt.subplots(1, 3, figsize=(15, 4))
        fig.patch.set_facecolor("#f8f9fa")

        # Panel A: Resultado del precio
        ax = axes[0]
        ax.set_facecolor("#eaf4fb")
        ax.axis("off")
        ax.text(0.5, 0.82, "Precio estimado",
                ha="center", fontsize=13, color="#555", transform=ax.transAxes)
        ax.text(0.5, 0.55, f"S/. {precio:,.0f}",
                ha="center", fontsize=30, fontweight="bold",
                color="#2980b9", transform=ax.transAxes)
        ax.text(0.5, 0.32,
                f"Rango: S/. {precio-margen:,.0f} – S/. {precio+margen:,.0f}",
                ha="center", fontsize=10, color="#777", transform=ax.transAxes)
        ax.text(0.5, 0.12, f"Tipo: {tipo_marca}",
                ha="center", fontsize=12, fontweight="bold",
                color=color_tipo, transform=ax.transAxes)
        ax.set_title("💰 Precio predicho", fontsize=12, fontweight="bold", pad=10)

        # Panel B: Specs del celular
        ax2 = axes[1]
        ax2.set_facecolor("#f0faf4")
        ax2.axis("off")
        specs = [
            ("RAM",            f"{ram} GB"),
            ("Almacenamiento", f"{alm} GB"),
            ("Cámara",         f"{cam} MP"),
            ("Batería",        f"{bat} mAh"),
        ]
        y_pos = 0.85
        for etiqueta, valor in specs:
            ax2.text(0.15, y_pos, etiqueta + ":",
                     fontsize=11, color="#555", transform=ax2.transAxes)
            ax2.text(0.72, y_pos, valor,
                     fontsize=11, fontweight="bold", color="#2c3e50",
                     transform=ax2.transAxes, ha="right")
            y_pos -= 0.18
        ax2.set_title("📋 Especificaciones", fontsize=12, fontweight="bold", pad=10)

        # Panel C: Reconocimiento de marca (barras de probabilidad)
        ax3 = axes[2]
        colores_marca = ["#1428A0", "#FF6900", "#555555", "#5D2D91"]
        bars = ax3.barh(marcas, probs * 100,
                        color=colores_marca, alpha=0.8, edgecolor="white")
        for bar, prob in zip(bars, probs):
            ax3.text(bar.get_width() + 0.5, bar.get_y() + bar.get_height() / 2,
                     f"{prob*100:.0f}%",
                     va="center", fontsize=9, color="#333")
        ax3.set_xlim(0, 115)
        ax3.set_xlabel("Probabilidad (%)")
        ax3.grid(axis="x", alpha=0.3)
        titulo_ia = f"🤖 Marca probable: {marca_pred}"
        if TENSORFLOW_DISPONIBLE:
            titulo_ia += f" ({confianza:.0%})"
        ax3.set_title(titulo_ia, fontsize=11, fontweight="bold", pad=10)

        plt.tight_layout()
        plt.show()

        # Tabla de comparación rápida
        print("\n" + "─" * 55)
        print(f"  RAM: {ram}GB  |  Alm: {alm}GB  |  Cámara: {cam}MP  |  Batería: {bat}mAh")
        print(f"  Precio estimado : S/. {precio:,.2f}")
        print(f"  Rango           : S/. {precio-margen:,.0f}  –  S/. {precio+margen:,.0f}")
        if TENSORFLOW_DISPONIBLE:
            print(f"  Marca probable  : {marca_pred} ({confianza:.0%} confianza)")
        print("─" * 55)

btn_predecir.on_click(predecir_y_mostrar)

# ── Mostrar la interfaz ───────────────────────────

panel_sliders = widgets.VBox([
    titulo,
    w_ram, w_alm, w_cam, w_bat,
    w_marca,
    btn_predecir,
    salida
], layout=widgets.Layout(padding="16px"))

display(panel_sliders)

# Ejecutar predicción inicial automáticamente
predecir_y_mostrar(None)


# =====================================================
# PASO 7: GRÁFICOS ORIGINALES DE LA PRÁCTICA
# =====================================================

print("\n📊 Gráficos de relación de datos...")

fig, axes = plt.subplots(1, 2, figsize=(12, 4))
fig.suptitle("Relación entre características y precio", fontsize=14, fontweight="bold")

colores_scatter = [
    "#c0392b" if p > 2500 else "#2980b9" if p > 1000 else "#27ae60"
    for p in df["precio"]
]

axes[0].scatter(df["ram"], df["precio"], c=colores_scatter, s=80, edgecolors="white", linewidths=0.5)
axes[0].set_xlabel("RAM (GB)")
axes[0].set_ylabel("Precio (S/.)")
axes[0].set_title("RAM vs Precio")
axes[0].grid(True, alpha=0.3)

axes[1].scatter(df["almacenamiento"], df["precio"], c=colores_scatter, s=80, edgecolors="white", linewidths=0.5)
axes[1].set_xlabel("Almacenamiento (GB)")
axes[1].set_ylabel("Precio (S/.)")
axes[1].set_title("Almacenamiento vs Precio")
axes[1].grid(True, alpha=0.3)

for ax in axes:
    for spine in ax.spines.values():
        spine.set_alpha(0.3)

plt.tight_layout()
plt.show()

# =====================================================
# FIN DEL PROGRAMA
# =====================================================

print("\n✅ Programa completo ejecutado correctamente.")