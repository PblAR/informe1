import tensorflow as tf
import numpy as np

# ==================================
# CARGAR MODELO TFLITE
# ==================================

interpreter = tf.lite.Interpreter(
    model_path="modelo_temperatura.tflite"
)

interpreter.allocate_tensors()

# ==================================
# OBTENER DETALLES
# ==================================

input_details = interpreter.get_input_details()

output_details = interpreter.get_output_details()

# ==================================
# SIMULAR SENSOR
# ==================================

temperaturas = [
    15,
    20,
    25,
    30,
    35
]

print("\nSIMULACION TINYML\n")

# ==================================
# PREDICCIONES
# ==================================

for temp in temperaturas:

    entrada = np.array(
        [[temp]],
        dtype=np.float32
    )

    interpreter.set_tensor(
        input_details[0]['index'],
        entrada
    )

    interpreter.invoke()

    salida = interpreter.get_tensor(
        output_details[0]['index']
    )

    fahrenheit = salida[0][0]

    print(
        f"{temp}°C -> "
        f"{fahrenheit:.2f}°F"
    )

    if temp > 25:

        print(
            "ALERTA: Temperatura elevada"
        )

    else:

        print(
            "Estado: Normal"
        )

    print("-" * 30)