import tensorflow as tf
import numpy as np
import matplotlib.pyplot as plt

# ==================================
# DATOS DE ENTRENAMIENTO
# ==================================

celsius = np.array(
    [0, 10, 20, 30, 40, 50],
    dtype=float
)

fahrenheit = np.array(
    [32, 50, 68, 86, 104, 122],
    dtype=float
)

# ==================================
# CREAR MODELO IA
# ==================================

modelo = tf.keras.Sequential([
    tf.keras.layers.Dense(
        units=1,
        input_shape=[1]
    )
])

# ==================================
# COMPILAR MODELO
# ==================================

modelo.compile(
    optimizer='adam',
    loss='mean_squared_error'
)

# ==================================
# ENTRENAMIENTO
# ==================================

print("\nEntrenando modelo...\n")

historial = modelo.fit(
    celsius,
    fahrenheit,
    epochs=500,
    verbose=False
)

print("Modelo entrenado correctamente\n")

# ==================================
# GRAFICO DE ENTRENAMIENTO
# ==================================

plt.figure(figsize=(8,5))

plt.plot(
    historial.history['loss']
)

plt.title(
    "Entrenamiento del Modelo"
)

plt.xlabel(
    "Épocas"
)

plt.ylabel(
    "Error"
)

plt.grid(True)

plt.show()

# ==================================
# PREDICCION
# ==================================

temperatura = 25.0

resultado = modelo.predict(
    np.array([temperatura]),
    verbose=0
)

print(
    f"{temperatura}°C = "
    f"{resultado[0][0]:.2f}°F"
)

# ==================================
# CONVERSION A TFLITE
# ==================================

converter = tf.lite.TFLiteConverter.from_keras_model(
    modelo
)

modelo_tflite = converter.convert()

with open(
    "modelo_temperatura.tflite",
    "wb"
) as archivo:

    archivo.write(modelo_tflite)

print(
    "\nModelo convertido a TensorFlow Lite"
)

print(
    "Archivo generado:"
)

print(
    "modelo_temperatura.tflite"
)