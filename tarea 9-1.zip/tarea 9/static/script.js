const temperaturas = [];

const ctx =
document.getElementById("grafico");

const chart =
new Chart(ctx, {

    type: "line",

    data: {

        labels: [],

        datasets: [{

            label: "Temperatura",

            data: []

        }]
    }
});

async function actualizar(){

    const res =
    await fetch("/datos");

    const datos =
    await res.json();

    document.getElementById(
        "temp"
    ).innerHTML =
    datos.temperatura + " °C";

    document.getElementById(
        "estado"
    ).innerHTML =
    datos.estado;

    document.getElementById(
        "prediccion"
    ).innerHTML =
    datos.prediccion.toFixed(2)
    + " °F";

    document.getElementById(
        "tinyml"
    ).innerHTML =
    datos.tinyml;

    chart.data.labels.push("");

    chart.data.datasets[0]
    .data.push(
        datos.temperatura
    );

    if(
        chart.data.labels.length > 20
    ){

        chart.data.labels.shift();

        chart.data.datasets[0]
        .data.shift();
    }

    chart.update();
}

setInterval(
    actualizar,
    1000
);

//nuevo codigo

// =====================================
// TEACHABLE MACHINE
// =====================================

const URL = "/static/modelo/";

let model;
let webcam;
let labelContainer;
let maxPredictions;

async function init() {

    try {

        const modelURL =
            URL + "model.json";

        const metadataURL =
            URL + "metadata.json";

        model = await tmImage.load(
            modelURL,
            metadataURL
        );

        maxPredictions =
            model.getTotalClasses();

        webcam =
            new tmImage.Webcam(
                300,
                300,
                true
            );

        await webcam.setup();

        await webcam.play();

        window.requestAnimationFrame(
            loop
        );

        document
            .getElementById(
                "webcam-container"
            )
            .appendChild(
                webcam.canvas
            );

        labelContainer =
            document.getElementById(
                "label-container"
            );

        labelContainer.innerHTML = "";

        for (
            let i = 0;
            i < maxPredictions;
            i++
        ) {

            labelContainer.appendChild(
                document.createElement("div")
            );
        }

    } catch (error) {

        console.error(error);

        alert(
            "Error al cargar el modelo"
        );
    }
}

async function loop() {

    webcam.update();

    await predict();

    window.requestAnimationFrame(
        loop
    );
}

async function predict() {

    const prediction =
        await model.predict(
            webcam.canvas
        );

    for (
        let i = 0;
        i < maxPredictions;
        i++
    ) {

        const texto =

            prediction[i].className +

            ": " +

            (
                prediction[i]
                .probability * 100
            ).toFixed(2)

            + "%";

        labelContainer
            .childNodes[i]
            .innerHTML = texto;
    }
}